
import React from 'react';
import ContactsNavigation from './navigation/ContactsNavigation';

export default function App() {
  return (
    <ContactsNavigation />
  )
}
